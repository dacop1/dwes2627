<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Circuito Eléctrico</title>
    
    <!-- css bootrstrap básico 5.3.8-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <!--icons bootstrap básico 5.3.8 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"> 
  </head>
  <body>
    <!--Capa principal de la aplicación -->
    <div class="container mt-3">
 
        <!-- Cabecera de la aplicación -->
        <header class="bg-primary text-white p-3 mb-3">
            <i class="bi bi-stack"></i> 
            <span class="fs-6">Calculo Circuito Electrico</span>
        </header>
 
        <!-- Contenido principal de la aplicación -->
        <main class="pb-5">
            <div class="content">
 
                <h1>Circuito Eléctrico</h1>
 
                <h3>Datos de Entrada</h3>
                <table class="table">
                    <tr class="table-danger">
                        <th>#</th>
                        <th>Magnitud</th>
                        <th class="text-end">Valor</th>
                        <th class="text-end">Unidad</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Voltaje</td>
                        <td class="text-end"><?= number_format($V, 2 , ',' , ' ') ?></td>
                        <td class="text-end">V</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Resistencia</td>
                        <td class="text-end"><?= number_format($R, 2 , ',' , ' ') ?></td>
                        <td class="text-end">R</td>
                    </tr>
                </table>
 
                <h3>Datos de Salida</h3>
                <table class="table">
                    <tr class="table-danger">
                        <th>#</th>
                        <th>Magnitud</th>
                        <th class="text-end">Valor</th>
                        <th class="text-end">Unidaad</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Intensidad de Corriente </td>
                        <td class="text-end" ><?= number_format($Intensidad, 2 , ',' , ' ') ?></td>
                        <td class="text-end">A</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Potencia Eléctrica </td>
                        <td class="text-end" ><?=  number_format($Potencia, 2 , ',' , ' ') ?></td>
                        <td class="text-end">W</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Energia Consumida</td>
                        <td class="text-end" ><?= number_format($Energia, 2 , ',' , ' ') ?></td>
                        <td class="text-end">J</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Resistenica </td>
                        <td class="text-end" ><?=number_format($ResistenciaParalelo, 2 , ',' , ' ') ?></td>
                        <td class="text-end"> </td>
                    </tr>
                </table>
 
                <div class="volver">
                    <a class="btn btn-outline-primary" href="index.php" role="button">Volver</a>
                </div>
 
            </div>
        </main>
 
        <!-- Pie de página de la aplicación -->
        <footer class="footer mt-auto py-3 fixed-bottom bg-light">
            <div class="container">
                <span class="text-muted">&copy;2026
                    Daniel Copete - DWES -2º DAW - Curso 26/27
                </span>
            </div>
        </footer>
 
        <!-- js bootstrap básico 5.3.8 -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
 
    </div>
  </body>
</html>