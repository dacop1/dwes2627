<?php
/**
 * Controlador: index.php
 * Descripción: controlador principal del proyecto
 * Examen práctico: Tema 2.Insercción de código php en HTML
 * Autor: Daniel Copete
 */
 
//incluir modelo
 
 
//incluir vista
include 'view/view.index.php';
 
 
 
?>
 