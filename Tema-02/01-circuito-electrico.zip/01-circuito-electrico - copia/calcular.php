<?php
/**
 * Controlador: calcular.php
 * Descripción: controlador principal del proyecto
 * Examen práctico: Tema 2.Insercción de código php en HTML
 * Autor: Daniel Copete
 */
 
// Cálculos
$V =  $_POST['voltaje']; 
$R =  $_POST['resistencia'];
 
$Intensidad = $V / $R;
$Potencia = $V * $Intensidad;
$Energia = $Potencia* 3600;
$ResistenciaParalelo = $R /2;
 
// Vista
include 'view/view.resultados.php';
 
 
 
?>
 